

CodeePy has been created to allow Codee the robot from the Creative Science Foundation to be controlled via Python.

For more information on how to create Codee including 3D printing files and firmware please visit;
[Instructables](https://www.instructables.com/id/Creative-Robotix-Educational-Platform-3DP/)

For more information on the Creative Science Foundation please visit;
[CreativeRobotix](http://www.creative-science.org/activities/robotix/)

![Image of Codee](https://cdn.pbrd.co/images/HIofnKw.jpg)

##Getting started
Please visit the [CodeePy Github](https://github.com/mefitzgerald/CodeePy) for installation information and code samples. 
				
